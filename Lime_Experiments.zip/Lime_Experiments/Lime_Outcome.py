import sys
import random
import io
import operator
import numpy as np
import lime
import lime.lime_tabular
import sklearn
import numpy as np
import sklearn
import random
import sklearn.ensemble
import sklearn.metrics
from sklearn import svm
from sklearn.metrics import f1_score
from sklearn.svm import SVC
from lime import lime_text
from sklearn.pipeline import make_pipeline
from lime.lime_text import LimeTextExplainer
import re
from lime.lime_text import LimeTextExplainer
from IPython.core.display import display, HTML
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import csr_matrix
from lime.lime_text import LimeTextExplainer
PNonSentWords = 0.25
class Lime:
	@classmethod
	def Lime_Explanation_Generator(cls):
		vectorizer = TfidfVectorizer(lowercase=False)

		file_lime_with_hiiden_pred=io.open("Lime_Explanation_update12.txt","w",encoding="ISO-8859-1")
		f1=open("full-meta-data.txt")
		ff2=io.open("reviewC.txt",encoding="ISO-8859-1")
		ff1=open("full-meta-data.txt")

		rev=[]
		Non_spam_user=[]
		posrev=[]
		Spam_user=[]
		negrev=[]
		revv=[]
		revus=[]
		revw=[]
		word=[]
		High_rating={}
		Low_rating={}
		rr={}
		rr1={}
		targets_t=[]
		targets_ts=[]
		trainm={}
		testm={}
		train1=[]
		train=[]
		test1=[]
		test=[]
		mt=[]
		c=0
		trainf=[]
		dd3={}
		#print(lb)
		Lw=[]
		Lweight=[]
		Lrev=[]
		word_weight={}
		final_lime={}
		h=0
		







		########################## train data processing for creating SVM  model #########################



		for t in f1:
			p=t.strip("\n").split("\t")
			#print(p)
			if float(p[3])>0:
				Non_spam_user.append(p[0])
				posrev.append(p[1])
			elif float(p[3])<0:
				Spam_user.append(p[0])
				negrev.append(p[1])

		f1.close()


		for t in ff1:
			p=t.strip("\n").split("\t")
			if float(p[2])>=1.0 and float(p[2])<3.0:
				Low_rating[p[0]]=0
			elif float(p[2])>=4.0 and float(p[2])<=5.0:
				#print("1")
				High_rating[p[0]]=2


		ff1.close()

		#print(Low_rating)
		totaluser=Non_spam_user+Spam_user

		for tt in ff2:
			#if h<2000:
				#h=h+1
				gh=[]
				p=tt.strip("\n").split("\t")
				#print(p)
				if len(p)>1:
					rr[p[0]]=p[3]
					pp=p[3].strip("\n").split()
					for gg in pp:
						gh.append(gg)
					rr1[p[0]]=gh
			




		for t in rr1:
			#pp=t.strip("\n").split()
			for oo in rr1[t]:
				if '/' not in oo and '.' not in oo and '(' not in oo and ')' not in oo and '-' not in oo and '!' not in oo and '$' not in oo and '%' not in oo and '^' not in oo and '&' not in oo and '^' not in oo and '*' not in oo and  '@' not in oo and '#' not in oo and '|' not in oo and "]" not in oo and '[' not in oo and ';' not in oo and ',' not in oo and '<' not in oo and '>' not in oo and '?' not in oo and '=' not in oo:
					train.append(oo)


		ss=set(train)

		for t in ss:
			trainf.append(t)

		#print(trainf)
		word_rating={}

		#print(rr2)
		#sys.exit()		
		for tt in rr1:
			for kk in High_rating:
				if str(tt)==str(kk):
					for bb in rr1[kk]:
						if bb in trainf:
							if bb not in word_rating:
								word_rating[bb]=2
								#print(bb,2)
		for tt in rr1:
			for kk in Low_rating:
				if str(tt)==str(kk):
					for bb in rr1[kk]:
						if bb in trainf:
							if bb not in word_rating:
								word_rating[bb]=0
								#print(bb,2)




		trainf1=[]
		target=[]
		for t in word_rating:
			trainf1.append(t)

		for t1 in word_rating.values():
			target.append(t1)
		#print(len(target),len(trainf1))

		test=[]

		targets_ts=[]
		tlm=int(len(trainf1)*0.2)

		for ty in range(0,tlm):
			test.append(trainf1[ty])
		for ty in range(0,int(len(target)*0.2)):
			targets_ts.append(target[ty])
		#print(targets_ts)
		#sys.exit()

		##################  training SVM model ####################

		train_vectors = vectorizer.fit_transform(trainf1)
		test_vectors = vectorizer.transform(test)
		clf =svm.SVC(C=100.0, cache_size=200, class_weight=None, coef0=0.0,decision_function_shape='ovr', degree=3, gamma='auto', kernel='linear',max_iter=-1, probability=True, random_state=None, shrinking=True,tol=0.0001, verbose=False).fit(train_vectors,target)#LinearSVC(C=1.0, class_weight=None, dual=True, fit_intercept=True,intercept_scaling=1, loss='squared_hinge', max_iter=100000,multi_class='ovr', penalty='l2', random_state=None, tol=0.000001,verbose=0).fit(train_vectors,targets_t) #SVC(kernel='rbf',C=1,decision_function_shape='ovo').fit(train_vectors,targets_t)

		#tt=clf.coef_
		#a = tt.todense()
		#df=tt.todense()
		#for t in df:
			#for k in  t:
				#print(len(k))
				
		#print(df) 

		#np.savetxt ("rating.csv",a,delimiter = ',')
		#sys.exit()
		#sys.exit()
		pv=clf.predict(test_vectors)
		pv.sort()

		#print(pv)
		pv1=[]

		#print(pv1)
		pv2=[]

		f=f1_score(targets_ts,pv,average='micro')
		print(f)
		#sys.exit()
		#print(len(train))

		############################ Creating Pipeline to feed SVM MOdel into LIME ########################################

		c = make_pipeline(vectorizer,clf)
		rtt=c.predict_proba([trainf1[0]]).round(3)
		print(rtt)

		mt1=['0','1'] #clasnames
		cna=mt1


		#explainer = lime.lime_tabular.LimeTabularExplainer(tr, feature_names=feature_names, class_names=targets_t, discretize_continuous=True)

		explainer = LimeTextExplainer(class_names=cna)

		#d22=sorted(dd3.items(),key=operator.itemgetter(1),reverse=True)

		for ii in range(0,len(trainf1)):
		        try:
		                            ww={}
		                            ww2={}
		                            wq=[]
		                            exp = explainer.explain_instance(trainf1[ii], c.predict_proba, labels=(0,1), top_labels=None, num_features=44055, num_samples=5000, distance_metric=u'cosine', model_regressor=None)# explainer.explain_instance(trainf[int(ii)], c.predict_proba, num_features=2961, labels=[0,1])#, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49])
		                            #print("jhhjvhhvhvhhg")
		                            tty=exp.as_list(label=int(0))
		                            print(tty)
		                            rtr=''
		                            for i in tty:
		                            	#print(i)
		                            	#rrr=random.randint(2,10)
		                            	mlp=random.uniform(0.8,1.1)
		                            	word_weight[i[0]]=abs(float(i[1]))*mlp
		        except:
		                	continue 


		#print(word_weight)


		for t in rr1:
			gh={}
			for k in word_weight:
				if k in rr1[t]:
					gh[k]=float(word_weight[k])
			d22=sorted(gh.items(),key=operator.itemgetter(1),reverse=True)
			#print(rr[t])
			#print("\n")
			#print(d22)
			file_lime_with_hiiden_pred.write(str(t))
			file_lime_with_hiiden_pred.write("\t")
			file_lime_with_hiiden_pred.write(str(rr[t]))
			file_lime_with_hiiden_pred.write("\n")
			file_lime_with_hiiden_pred.write("Explanation in terms of weights")
			file_lime_with_hiiden_pred.write("\n")
			file_lime_with_hiiden_pred.write(str(d22))
			file_lime_with_hiiden_pred.write("\n")



Exp=Lime.Lime_Explanation_Generator()
