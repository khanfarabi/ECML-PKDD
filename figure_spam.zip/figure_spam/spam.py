import numpy as np
import matplotlib.pyplot as plt
from matplotlib.dates import date2num
import sys
import pylab 
x1 = np.linspace(0, 20, 1000)

pre=[2.95,3.23,2.47]
re=[4.02,3.61,3.52]


x2=0
y2=0
#plt.title('Proposed Scheme vs Lime for Spam Prediction')

#plt.grid(True)
Lc1=['Q6','Q7','Q8']
#plt.hist(L22,density=100, bins=200) 
#plt.axis([0,6,0,50]) 
#axis([xmin,xmax,ymin,ymax])
#txt="Our Approach vs LIME for Spam"

# make some synthetic data


#fig = plt.figure()
#fig.text(.5, .015, txt, ha='center')
#plt.xlabel('Q6,Q7 and Q8 ')
#plt.xlabel('Queries of Survey Q:6-8 ')
plt.ylabel('Average Ratings')
x = np.array([0,1,2])
ax = plt.subplot(111)
ax.bar(x-0.20,pre,width=0.25,color='b',align='center')
ax.bar(x+0.20,re,width=0.25,color='r',align='center')
pylab.plot(x2, y2, '-b', label='LIME')
pylab.plot(x2,y2, '-r', label='Our Approach')
pylab.legend(loc='right left')
#pylab.ylim(-1.5, 2.0)

#plt.bar(x,pre)
#plt1.bar(x,re)
plt.xticks(x,Lc1)
plt.show()
pylab.show()
