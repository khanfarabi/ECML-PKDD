import pandas as pd 
import sys
import random 



dataframe = pd.read_excel("Explanations_Review_Ratings.xlsx",header=None, skiprows=0)

#print(dataframe.describe)
df={}
for www in range(9,17):
	hj=[]
	for w in dataframe[www]:
		jj=str(w).strip("\n \t '").split()
		for k in jj:
			for w1 in range(0,6):
				if str(w1)==k:
					hj.append(k)
	df[www-9]=hj


c1=0
c2=0
c3=0
c4=0
c5=0
sc1={}
jk=[]
#for tr in range(0,8):
for t in df[4]:
		if t=='1':
			c1=c1+1
		elif t=='2':
			 c2=c2+1
		elif t=='3':
			 c3=c3+1
		elif t=='4':
			 c4=c4+1
		elif t=='5':
			 c5=c5+1

print(c1/32.0,c2/32.0,c3/32.0,c4/32.0,c5/32.0)

#for t in range(5,8):
	  #dd=0
	  #for t1 in df[t]:
      			#dd=dd+float(t1)
	 # print(dd/32.0)



